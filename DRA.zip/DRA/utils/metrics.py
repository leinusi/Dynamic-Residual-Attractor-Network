import torch
import torch.nn.functional as F

def calculate_intra_class_compactness(features, labels):
    unique_labels = torch.unique(labels)
    compactness = 0.0
    for label in unique_labels:
        class_features = features[labels == label]
        class_mean = torch.mean(class_features, dim=0, keepdim=True)
        compactness += torch.mean(torch.norm(class_features - class_mean, dim=1)) / len(unique_labels)
    return compactness

def calculate_inter_class_distance(features, labels):
    unique_labels = torch.unique(labels)
    class_centers = []
    for label in unique_labels:
        class_features = features[labels == label]
        class_center = torch.mean(class_features, dim=0, keepdim=True)
        class_centers.append(class_center)
    class_centers = torch.cat(class_centers, dim=0)
    
    distance = 0.0
    n = len(class_centers)
    for i in range(n):
        for j in range(i + 1, n):
            cos_sim = F.cosine_similarity(class_centers[i], class_centers[j], dim=0)
            distance += (1 - cos_sim) / (n * (n - 1) / 2)
    return distance
