import matplotlib.pyplot as plt
import numpy as np
from sklearn.manifold import TSNE

def visualize_features(features, labels, title='Features Visualization using t-SNE', filename='features_tsne_visualization.png'):
    tsne = TSNE(n_components=2, random_state=123)
    reduced_features = tsne.fit_transform(features)
    
    plt.figure(figsize=(10, 10))
    colors = plt.cm.winter(np.linspace(0, 1, len(np.unique(labels))))
    
    for i, color in zip(np.unique(labels), colors):
        indexes = labels == i
        plt.scatter(reduced_features[indexes, 0], reduced_features[indexes, 1], label=i, color=color)
    
    plt.legend()
    plt.title(title)
    plt.grid(True)
    plt.savefig(filename)
