import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10
from torchvision.transforms import Compose, ToTensor, Normalize, Resize
from torchvision.models import resnet18,vit_l_16
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision.datasets import CIFAR10, ImageFolder
from torchvision.transforms import Compose, ToTensor, Normalize, Resize
from torch.utils.data import random_split
from torchvision.models import vit_l_16,resnet18  # 导入ViT-Large模型
import torch.nn.functional as F
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import numpy as np


class LearningModelTrainer:
    def __init__(self, feature_extractor, attention_attractor_net, config):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.feature_extractor = feature_extractor.to(self.device)
        self.attention_attractor_net = attention_attractor_net.to(self.device)
        self.config = config

    def pretrain(self, loader):
        optimizer = optim.SGD(self.feature_extractor.parameters(), lr=self.config["lr"], momentum=0.9)
        criterion = nn.CrossEntropyLoss()

        self.feature_extractor.train()
        for epoch in range(self.config["pretrain_epochs"]):
            for i, (images, labels) in enumerate(loader):
                images, labels = images.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                outputs = self.feature_extractor(images)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                if (i + 1) % 100 == 0:
                    print(f"Pretrain Epoch [{epoch+1}/{self.config['pretrain_epochs']}], Step [{i+1}/{len(loader)}], Loss: {loss.item():.4f}")

    def train_attractor_network(self, loader):
        self.feature_extractor.eval()  # 设置特征提取器为评估模式
        optimizer = optim.AdamW(self.attention_attractor_net.parameters(), lr=self.config["meta_lr"])
        criterion = nn.CrossEntropyLoss()
        lambda_reg = self.config["lambda_reg"]

        for epoch in range(self.config["attraction_epochs"]):
            total_loss_accumulated = 0  # 累积损失，用于日志
            for j, (images, labels) in enumerate(loader):
                images, labels = images.to(self.device), labels.to(self.device)
            
                # 获取特征表示
                with torch.no_grad():  # 不更新特征提取器的梯度
                    features = self.feature_extractor(images)
            
                # 计算吸引子网络的输出和分类损失
                optimizer.zero_grad()
                outputs = self.attention_attractor_net(features)
                classification_loss = criterion(outputs, labels)
            
                # 计算正则化损失
                reg_loss = self.attention_attractor_net.regularize_attractors()

                # 计算总损失并进行反向传播
                total_loss = classification_loss + lambda_reg * reg_loss
                total_loss.backward()
                optimizer.step()

                total_loss_accumulated += total_loss.item()

                if (j + 1) % 100 == 0:
                    avg_loss = total_loss_accumulated / 100
                    print(f"Attraction Epoch [{epoch+1}/{self.config['attraction_epochs']}], Step [{j+1}/{len(loader)}], Avg Loss over last 100 steps: {avg_loss:.4f}")
                    total_loss_accumulated = 0  # 重置累积损失

        

    def evaluate_accuracy(self, loader):
        self.feature_extractor.eval()
        self.attention_attractor_net.eval()
        correct = 0
        total = 0

        with torch.no_grad():
            for images, labels in loader:
                images, labels = images.to(self.device), labels.to(self.device)
                features = self.feature_extractor(images)
                outputs = self.attention_attractor_net(features)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = correct / total
        print(f'Accuracy on the test dataset: {accuracy * 100:.2f}%')

    def visualize_features(self, loader):
        self.feature_extractor.eval()
        self.attention_attractor_net.eval()
        
        features_list = []
        labels_list = []
        
        with torch.no_grad():
            for images, labels in loader:
                images, labels = images.to(self.device), labels.to(self.device)
                features = self.feature_extractor(images)
                features_list.append(features.cpu().numpy())
                labels_list.append(labels.cpu().numpy())
                
        # Concatenate lists to form arrays
        features_array = np.concatenate(features_list, axis=0)
        labels_array = np.concatenate(labels_list, axis=0)
        
        # Apply t-SNE
        tsne = TSNE(n_components=2, random_state=123)
        reduced_features = tsne.fit_transform(features_array)
        
        # Visualize
        plt.figure(figsize=(10, 10))
        colors = plt.cm.winter(np.linspace(0, 1, len(np.unique(labels_array))))  # Use the 'winter' colormap

        for i, color in zip(np.unique(labels_array), colors):
            indexes = labels_array == i
            plt.scatter(reduced_features[indexes, 0], reduced_features[indexes, 1], label=i, color=color)

        plt.legend()
        plt.title("Features Visualization using t-SNE")
        plt.grid(True)  # Add a grid for a more standard look
        plt.savefig("features_tsne_visualization.png")
    def evaluate_metrics(self, loader):
        self.feature_extractor.eval()
        self.attention_attractor_net.eval()
        features_list = []
        labels_list = []
        
        with torch.no_grad():
            for images, labels in loader:
                images, labels = images.to(self.device), labels.to(self.device)
                features = self.feature_extractor(images)
                features_list.append(features)
                labels_list.append(labels)
                
        features = torch.cat(features_list, dim=0)
        labels = torch.cat(labels_list, dim=0)
        
        # 计算并打印类内紧致度和类间距离
        compactness = self.attention_attractor_net.calculate_intra_class_compactness(features, labels)
        inter_class_distance = self.attention_attractor_net.calculate_inter_class_distance(features, labels)
        print(f"Class Intra-Compactness: {compactness.item():.4f}")
        print(f"Inter-Class Distance: {inter_class_distance.item():.4f}")