import torch
import torch.nn as nn
from torchvision.models import vit_l_16,resnet18
'''
class FeatureExtractor(nn.Module):
    def __init__(self, pretrained=True):
        super(FeatureExtractor, self).__init__()
        self.model = vit_l_16(pretrained=pretrained)
        self.model.head = nn.Identity()  # Replace the classification head with an identity function
        self.out_features = 1000  # Feature dimension for ViT-Large

    def forward(self, x):
        x = self.model(x)
        return x
'''
class FeatureExtractor(nn.Module):
    def __init__(self, pretrained=True):
        super(FeatureExtractor, self).__init__()
        backbone = resnet18(pretrained=pretrained)
        self.features = nn.Sequential(*list(backbone.children())[:-1])
        self.out_features = 512

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        return x