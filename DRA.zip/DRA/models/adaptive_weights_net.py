import torch
import torch.nn as nn

class AdaptiveWeightsNet(nn.Module):
    def __init__(self, feature_dim, num_classes):
        super(AdaptiveWeightsNet, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(feature_dim, feature_dim // 2),
            nn.ReLU(),
            nn.Linear(feature_dim // 2, num_classes),
            nn.Softmax(dim=1)
        )
    
    def forward(self, features):
        weights = self.mlp(features)
        return weights
    
    
    
    
    
    

