import torch
import torch.nn as nn

class DistanceMetric(nn.Module):
    def __init__(self, feature_dim):
        super(DistanceMetric, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, 1),
            nn.ReLU()
        )
    
    def forward(self, attractor1, attractor2):
        combined_features = torch.cat((attractor1, attractor2), dim=1)
        distance = self.mlp(combined_features)
        return distance
