import torch
import torch.nn as nn
from .distance_metric import DistanceMetric
from .adaptive_weights_net import AdaptiveWeightsNet

class DynamicResidualFeatureAggregationNetwork(nn.Module):
    def __init__(self, num_classes, feature_dim):
        super(DynamicResidualFeatureAggregationNetwork, self).__init__()
        self.attractors = nn.Parameter(torch.zeros(num_classes, feature_dim))
        nn.init.kaiming_normal_(self.attractors, mode='fan_out', nonlinearity='relu')

        self.mlp = nn.Sequential(
            nn.Linear(feature_dim, feature_dim // 2),
            nn.ReLU(inplace=True),
            nn.Linear(feature_dim // 2, num_classes)
        )

        self.distance_metric = DistanceMetric(feature_dim)
        self.adaptive_weights_net = AdaptiveWeightsNet(feature_dim, num_classes)

    def forward(self, features):
        adaptive_weights = self.adaptive_weights_net(features)
        weighted_attractors = self.attractors * adaptive_weights.unsqueeze(2)
        aggregated_features = torch.bmm(adaptive_weights.unsqueeze(1), weighted_attractors).squeeze(1)
        combined_features = features + aggregated_features
        processed_features = self.mlp(combined_features)
        return processed_features
    
    def train_attractor_network(self, loader):
        self.feature_extractor.eval()  # 设置特征提取器为评估模式
        optimizer = optim.AdamW(self.attention_attractor_net.parameters(), lr=self.config["meta_lr"])
        criterion = nn.CrossEntropyLoss()
        lambda_reg = self.config["lambda_reg"]

        for epoch in range(self.config["attraction_epochs"]):
            total_loss_accumulated = 0  # 累积损失，用于日志
            for j, (images, labels) in enumerate(loader):
                images, labels = images.to(self.device), labels.to(self.device)
            
                # 获取特征表示
                with torch.no_grad():  # 不更新特征提取器的梯度
                    features = self.feature_extractor(images)
            
                # 计算吸引子网络的输出和分类损失
                optimizer.zero_grad()
                outputs = self.attention_attractor_net(features)
                classification_loss = criterion(outputs, labels)
            
                # 计算正则化损失
                reg_loss = self.attention_attractor_net.regularize_attractors()

                # 计算总损失并进行反向传播
                total_loss = classification_loss + lambda_reg * reg_loss
                total_loss.backward()
                optimizer.step()

                total_loss_accumulated += total_loss.item()

                if (j + 1) % 100 == 0:
                    avg_loss = total_loss_accumulated / 100
                    print(f"Attraction Epoch [{epoch+1}/{self.config['attraction_epochs']}], Step [{j+1}/{len(loader)}], Avg Loss over last 100 steps: {avg_loss:.4f}")
                    total_loss_accumulated = 0  # 重置累积损失

    def regularize_attractors(self):
        reg_loss = 0
        num_attractors = self.attractors.size(0)
        for i in range(num_attractors - 1):
            for j in range(i + 1, num_attractors):
                distance = self.distance_metric(self.attractors[i:i+1], self.attractors[j:j+1])
                reg_loss += distance.squeeze()
        reg_loss /= (num_attractors * (num_attractors - 1) / 2)
        return reg_loss